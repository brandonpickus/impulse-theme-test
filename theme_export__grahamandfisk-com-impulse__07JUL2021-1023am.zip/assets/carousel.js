$(document).ready(function() {
  $('.logo-carousel').slick({
    slidesToShow: 5,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 1000,
    arrows: true,
    dots: false,
    pauseOnHover: true,
    responsive: [
      {
      breakpoint: 1300,
      settings: {
        slidesToShow: 4
      }
    },{
      breakpoint: 820,
      settings: {
        slidesToShow: 3
      }
    }, {
      breakpoint: 520,
      settings: {
        slidesToShow: 2
      }
    }]
  });
});