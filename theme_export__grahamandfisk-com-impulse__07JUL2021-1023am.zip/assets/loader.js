window.onload = function(){
  document.getElementById("loadera").style.display='none';
};